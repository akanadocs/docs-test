#!/bin/bash
# $Id$
# $Revision$

PATH=/opt/oracle/instantclient_11_2:$PATH
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/oracle/instantclient_11_2

SID=""
DB_USER=""
DB_PASS=""
DB_HOST=""
DB_PORT="1521"

sqlcmd="sqlplus -S ${DB_USER}/${DB_PASS}@'(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=${DB_HOST})(PORT=${DB_PORT})))(CONNECT_DATA=(SID=${SID})))'"

date
$sqlcmd <<EOF
delete from MO_USAGE_NEXTHOP where REQUESTDTS < (SYSTIMESTAMP - INTERVAL '1' MONTH);
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from MO_USAGEMSGS where MSGCAPTUREDDTS < (SYSTIMESTAMP - INTERVAL '1' MONTH);
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from MO_USAGEDATA where REQUESTDTS < (SYSTIMESTAMP - INTERVAL '1' MONTH);
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from MO_ROLLUPDATA where ROLLUPDATAID < (select min(MAX_ID) from MO_STATUS) and INTVLSTARTDTS < (SYSTIMESTAMP - INTERVAL '1' MONTH);
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from MO_ROLLUP15 where INTVLSTARTDTS < (SYSTIMESTAMP - INTERVAL '1' MONTH);
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from MO_ROLL_ORG15 where INTVLSTARTDTS < (SYSTIMESTAMP - INTERVAL '1' MONTH);
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from MO_ROLLUP_HOUR where INTVLSTARTDTS < (SYSTIMESTAMP - INTERVAL '3' MONTH);
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from MO_ROLL_ORG_H where INTVLSTARTDTS < (SYSTIMESTAMP - INTERVAL '3' MONTH);
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from MO_ROLLUP_DAY where INTVLSTARTDTS < (SYSTIMESTAMP - INTERVAL '1' YEAR);
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from MO_ROLL_ORG_D where INTVLSTARTDTS < (SYSTIMESTAMP - INTERVAL '1' YEAR);
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from AM_EMAILALERTS e WHERE EXISTS (select a.ALERTSID from AM_ALERTS a where a.ALERTSID = e.ALERTSID and a.SOURCEDTS < (SYSTIMESTAMP - INTERVAL '1' MONTH));
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from AM_ALERTS_SLAS s WHERE EXISTS (select a.ALERTSID from AM_ALERTS a where a.ALERTSID = s.ALERTSID and a.SOURCEDTS < (SYSTIMESTAMP - INTERVAL '1' MONTH));
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from AM_ALERTS where SOURCEDTS < (SYSTIMESTAMP - INTERVAL '1' MONTH);
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from BOARD_ITEM_ASSIGNMENTS where ITEMID in (select ITEMID from BOARD_ITEMS where ARCHIVABLE='Y' and CREATED < (SYSTIMESTAMP - INTERVAL '1' YEAR));
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from BOARD_ITEMS where ARCHIVABLE='Y' and CREATED < (SYSTIMESTAMP - INTERVAL '1' YEAR);
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from API_CONTRACT_SLA_DATA where LASTMODIFIEDDTS < (SYSTIMESTAMP - INTERVAL '1' YEAR);
EOF
[ $? != 0 ] && exit 1

date
$sqlcmd <<EOF
delete from API_SLA_DATA where LASTMODIFIEDDTS < (SYSTIMESTAMP - INTERVAL '1' YEAR);
EOF
[ $? != 0 ] && exit 1

date