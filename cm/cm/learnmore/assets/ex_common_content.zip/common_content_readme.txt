To use the common content readme:
- Upload the content
- Test the content

Uploading the content
1) Log in to the developer portal as a Site Admin.
2) Go to Admin > Config > Resources > Content File Manager. 
   The File Manager opens at the /content folder.
3) Navigate down two levels to home/learnmore.
4) In the learnmore folder, click Upload a ZIP Archive and upload the file.
   The file unzips automatically.

Testing the content
1) Go to the developer portal home page ({URL}/home/landing)/
2) Change the last part of the URL from /landing to /learnmore.
   The main index page, index.htm, is displayed, with the two pieces of common content.
3) In the Related Topics section, click the links to the other files. This is how
   the navigational element works.

-----------------------------------------------------------------

The common content ZIP file is intended to be uploaded to the /learnmore folder in 
the developer portal. It includes:
- Root folder with five files, each one with two include tags:
  - index.htm
  - 01.htm
  - 02.htm
  - 03.htm
  - 04.htm
- Subfolder, /common, with two shared content files:
  - include_relatedtopics.htm
  - include_versioninfo.htm
- Subfolder, /style, with one file, document.css
- This readme

-----------------------------------------------------------------
